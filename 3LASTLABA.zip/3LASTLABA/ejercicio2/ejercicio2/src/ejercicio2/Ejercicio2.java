/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nombre ="luisa";
        String apellido ="amezquitas";
        
        System.out.println("ingrese su nombre");
        Scanner D = new Scanner(System.in);
        nombre = D.nextLine();
        
        System.out.println("ingrese su apellido");
        Scanner D1 = new Scanner(System.in);
        apellido = D1.nextLine();
        
        System.out.println("bienvenida " +nombre  + apellido);
        
    }
    
}
